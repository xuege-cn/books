(function (modules) {
    const installedModule = {}
    function hotCreateRequire (moduleId) {
        const parentModule = installedModule[moduleId]
        if (!parentModule) return __webpack_require__
        const hotRequire =  (childModuleId) => {
            __webpack_require__(childModuleId);
            const childModule = installedModule[childModuleId];
            parentModule.children.push(childModule);
            childModule.parents.push(parentModule);
            return childModule.exports;
        }
        return hotRequire;
    }

    function hotCheck (hash) {
        hotDownloadManifest(hash).then(update => {
            hotDownloadUpdateChunk(update.c, hash)
        })
    }

    function hotDownloadManifest (hash) {
        return new Promise(resolve => {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', `${hash}.hot-update.json`);
            xhr.responseType = 'json';
            xhr.onload = function () {
                resolve(xhr.response)
            }
            xhr.send();
        })
    }

    function hotDownloadUpdateChunk (chunks, hash) {
        const chunkNames = Object.keys(chunks);
        chunkNames.forEach(chunkName => {
            const script = document.createElement('script');
            script.src = `${chunkName}.${hash}.hot-update.js`;
            document.head.appendChild(script);
            script.onload = () => {
                document.head.removeChild(script);
            }
        })
    }

    window['webpackHotUpdate'] = (chunkId, moreChunks) => {
        const chunkNames = Object.keys(moreChunks)
        chunkNames.forEach(chunkName => {
            modules[chunkName] = moreChunks[chunkName]
            const oldModule = installedModule[chunkName];
            delete installedModule[chunkName];
            oldModule.parents.forEach(parentModule => {
                const cb = parentModule.hot._acceptedDependencies[chunkName]
                cb && cb()
            })
        })
    }

    function __webpack_require__ (moduleId) {
        if (installedModule[moduleId]) {
            return installedModule[moduleId]
        }
        let hot = {
            _acceptedDependencies: {},
            accept: (dependencies, render) => {
                dependencies.forEach(dependency => {
                    hot._acceptedDependencies[dependency] = render;
                })
            },
            check: hotCheck
        }
        const module = installedModule[moduleId] = {
            id: moduleId,
            load: false,
            exports: {},
            hot,
            parents: [],
            children: []
        }
        modules[moduleId].call(module.exports, module, module.exports, hotCreateRequire(moduleId))
        return module.exports
    }

    __webpack_require__("0")
})({
    "./src/index.js": (function(module, exports, __webpack_require__) {
        eval("const input = document.createElement('input');\ndocument.body.appendChild(input);\n\nconst div = document.createElement('div');\ndocument.body.appendChild(div);\n\nfunction render () {\n  const title = __webpack_require__(/*! ./title.js */ \"./src/title.js\");\n  div.innerHTML = title;\n}\n\nrender()\n\nif (true) {\n  module.hot.accept([/*! ./title.js */ \"./src/title.js\"], render)\n}\n\n//# sourceURL=webpack:///./src/index.js?");
    }),
    "./src/title.js": (function(module, exports) {
        eval("module.exports = 'hello world'\n\n//# sourceURL=webpack:///./src/title.js?");
    }),
    "./webpack-dev-server/client/eventEmitter.js": (function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        class EventEmitter {
            constructor () {
                this.events = {}
            }
            on (eventName, callback) {
                this.events[eventName] || (this.events[eventName] = []);
                this.events[eventName].push(callback)
            }
            emit (eventName, ...args) {
                const callbacks = this.events[eventName];
                callbacks.forEach(callback => callback && callback(...args));
            }
        }
        module.exports = (new EventEmitter());
    }),
    "./webpack-dev-server/client/index.js": (function(module, __webpack_exports__, __webpack_require__) {
        var hotEventEmitter = __webpack_require__("./webpack-dev-server/client/eventEmitter.js");
        let hot = false
        const socket = io('/');
        let currentHash;
        socket.on('hash', hash => {
            currentHash = hash
        });
        socket.on('ok', () => {
            reloadApp();
        });
        socket.on('hot', () => {
            hot = true
        });
        function reloadApp () {
            if (!hot) {
                window.location.reload();
            } else {
                hotEventEmitter.emit('webpackHotUpdate', currentHash)
            }
        }
    }),
    "./webpack/hot/dev-server.js": (function(module, __webpack_exports__, __webpack_require__) {
        const hotEventEmitter = __webpack_require__('./webpack-dev-server/client/eventEmitter.js');
        let lastHash;
        hotEventEmitter.on('webpackHotUpdate', currentHash => {
            lastHash && module.hot.check(lastHash);
            lastHash = currentHash;
        })
    }),
    0: (function(module, exports, __webpack_require__) {
        __webpack_require__("./webpack-dev-server/client/index.js");
        __webpack_require__("./webpack/hot/dev-server.js");
        module.exports = __webpack_require__("./src/index.js");
    })
})