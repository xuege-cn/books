const Server = require('./Server');
const webpack = require('webpack');
const config = require('../webpack.config');
const compiler = webpack(config);
const server = new Server(compiler);
server.listen(9090, () => {
  console.log('server startup!')
})