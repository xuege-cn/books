const path = require('path');

function updateCompiler (compiler) {
  const config = compiler.options;
  config.entry = {
    main: [
      path.join(__dirname, '../client/index.js'),
      path.join(__dirname, '../../webpack/hot/dev-server.js'),
      config.entry
    ]
  }
  compiler.hooks.entryOption.call(config.context, config.entry);
}

module.exports = updateCompiler