class EventEmitter {
  constructor () {
    this.events = {}
  }
  on (eventName, callback) {
    this.events[eventName] || (this.events[eventName] = []);
    this.events[eventName].push(callback)
  }
  emit (eventName, ...args) {
    const callbacks = this.events[eventName];
    callbacks.forEach(callback => callback && callback(...args));
  }
}

export default new EventEmitter();