const http = require('http');
const path = require('path');
const mime = require('mime');
const express = require('express');
const fs = require('fs-extra');
fs.join = path.join;
const socketIO = require('socket.io')
const updateCompiler = require('./utils/updateCompiler');

class Server {
  constructor (compiler) {
    // 1：挂载compiler打包完成事件
    //    1.1 记录hash值
    //    1.2 向客户端发送两个事件：hash，ok
    // 2：watch模式启动compiler
    // 3：compiler.outputFileSystem 标志为 memory-fs
    this.compiler = compiler;
    this.clientSocketList = [];
    updateCompiler(compiler);
    this.setupHooks();

    // 4：路由
    //    4.1 真实webpack-dev-server是使用内存文件系统的，需要从内存中去读
    this.app = express();
    this.routes();
    this.server = http.createServer(this.app);

    // 5：创建socket服务
    this.setupSocket();
  }

  setupSocket () {
    const io = socketIO(this.server);
    io.on('connection', socket => {
      socket.emit('hot');
      socket.emit('hash', this.currentHash);
      socket.emit('ok');
      const index = this.clientSocketList.push(socket);
      io.on('disconnect', () => {
        this.clientSocketList.splice(index - 1, 1)
      })
    })
  }

  setupHooks () {
    const { compiler } = this;
    compiler.hooks.done.tap('webpack-dev-server', ({ hash }) => {
      this.currentHash = hash;
      this.clientSocketList.forEach(socket => {
        socket.emit('hash', hash);
        socket.emit('ok');
      })
    });
    compiler.watch({}, () => {
      console.log('file changed, webpack recompile!')
    })
    this.fs = compiler.outputFileSystem = fs
  }

  listen (port, callback) {
    this.server.listen(port, callback)
  }

  routes () {
    const { compiler: { options } } = this
    this.app.use(async (req, res, next) => {
      const { url } = req;
      if (url === '/favicon.ico') {
        res.sendStatus(404);
      }
      const staticPath = options.output.path;
      const filePath = path.join(staticPath, url);
      try {
        const fileStats = this.fs.statSync(filePath);
        if (fileStats.isFile()) {
          const content = this.fs.readFileSync(filePath);
          res.setHeader('Content-Type', mime.getType(filePath));
          res.send(content);
          next();
        } else {
          res.sendStatus(404)
        }
      } catch (e) {
        console.log('error:', e)
        res.sendStatus(404)
      }
    })
  }
}

module.exports = Server