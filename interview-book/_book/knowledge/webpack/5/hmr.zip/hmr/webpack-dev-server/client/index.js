import hotEventEmitter from './eventEmitter'

let hot = false
const socket = io('/');
socket.on('hash', hash => {
  console.log('hash', hash)
});
socket.on('ok', () => {
  reloadApp();
});
socket.on('hot', () => {
  hot = true
});

function reloadApp () {
  if (!hot) {
    window.location.reload();
  } else {
    hotEventEmitter.emit('webpackHotUpdate')
  }
}