const webpack = require('webpack')
const htmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
  mode: 'development',
  entry: './src/index.js',
  devServer: {
    hot: true
  },
  plugins: [
    new htmlWebpackPlugin({
      template: './webpack-dev-server/index.html',
    }),
    new webpack.HotModuleReplacementPlugin()
  ]
}