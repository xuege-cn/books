import hotEventEmitter from '../../webpack-dev-server/client/eventEmitter';

let lastHash;
hotEventEmitter.on('webpackHotUpdate', currentHash => {
  module.hot.check(lastHash);
  lastHash = currentHash;
})