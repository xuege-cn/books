class Base {
    constructor (router) {
        this.router = router
        this.current = null;
    }

    transitionTo (path, handler) {
        const updateRouter = () => {
            this.current = this.router.matcher.match(path, this.current || {})
            handler && handler();
        }

        const runHooks = () => {
            const from = this.current.path
            const beforeHooks = this.router.beforeHooks
            if (beforeHooks && beforeHooks.length) {
                beforeHooks.reduce((prev, current, idx) => {
                    let next = current
                    if (idx === (beforeHooks.length - 1)) {
                        next = () => current(path, from, updateRouter)
                    }
                    return prev ? prev(path, from, next) : current;
                })
            }
        }
        
        (this.current ? runHooks : updateRouter)()
    }
}

export default Base;