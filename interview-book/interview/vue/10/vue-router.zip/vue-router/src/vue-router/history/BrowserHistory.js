import Base from './Base'


class BrowserHistory extends Base {
    constructor (router) {
        super(router)
    }

    getCurrentLocation () {
        return window.location.pathname
    }

    setupListener () {
        window.addEventListener('popstate', () => {
            this.transitionTo(
                this.getCurrentLocation()
            )
        })
    }

    push (location) {
        history.pushState({}, '', location)
    }
}

export default BrowserHistory;