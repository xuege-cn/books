const Link = {
    props: {
        to: String,
    },
    render (h) {
        return h(
            'a',
            {
                attrs: {
                    href: this.to
                },
                on: {
                    click: this.clickEvt
                }
            },
            [
                this.$slots.default
            ]
        )
    },
    methods: {
        clickEvt (e) {
            e.preventDefault();
            this._routerRoot._router.push(this.to);
        }
    }
}

export default Link;