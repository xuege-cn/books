const View = {
    functional: true,
    render (createElement, context) {
        let depth = 0;
        let comp = context.parent
        const matched = comp._routerRoot._router.history.current.matched;

        let parent = comp.$parent
        while (parent) {
            const vnode = parent.$vnode
            if (vnode && vnode.data.routerView) {
                depth++
            }
            parent = parent.$parent
        }

        if (Array.isArray(matched)) {
            const router = matched[depth]
            comp.$vnode.data.routerView = true
            if (router) {
                return createElement(router.component)
            }
        }
    }
}

export default View;