import RouterLink from './components/link'
import RouterView from './components/view'
import HashHistory from './history/HashHistory'
import BrowserHistory from './history/BrowserHistory'
import createMatcher from './matcher/create-matcher'

class VueRouter {
    constructor (options) {
        this.mode = options.mode;
        this.matcher = createMatcher(options.routes);
        switch (this.mode) {
            case 'hash':
                this.history = new HashHistory(this);
                break;
            case 'history':
                this.history = new BrowserHistory(this);
                break;
        }
    }

    init (app) {
        this.app = app;
        const history = this.history;
        history.transitionTo(
            history.getCurrentLocation(),
            history.setupListener.bind(history)
        );
    }

    addRoutes (routes) {
        this.matcher.addRoutes(routes);
    }

    push (location) {
        this.history.push(location)
    }

    beforeHook (hook) {
        (this.beforeHooks || (this.beforeHooks = [])).push(hook);
    }
}

VueRouter.install = function (Vue) {
    Vue.mixin({
        beforeCreate () {
            if (this.$options.router) {
                this._routerRoot = this;
                this._router = this.$options.router

                this._router.init(this)
                Vue.util.defineReactive(this, '_route', this._router.history.current)
            } else {
                this._routerRoot = this.$parent && this.$parent._routerRoot
            }
        }
    })

    Vue.component('router-link', RouterLink);
    Vue.component('router-view', RouterView);
}

export default VueRouter