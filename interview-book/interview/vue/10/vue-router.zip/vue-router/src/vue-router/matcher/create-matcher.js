function createMatcher (routes) {
    let { pathMap } = createPathMap(routes);

    function addRoutes (routes) {
        createPathMap(routes, pathMap);
        console.log('【匹配器】路由拍平：', pathMap)
    }

    function match (path, _route) {
        let matched = []
        let record = pathMap[path]
        if (record) {
            matched.push(record)
            while(record.parent) {
                matched.unshift(record.parent)
                record = record.parent
            }
        }
        _route.path = path
        _route.matched = matched
        return _route;
    }

    console.log('【匹配器】路由拍平：', pathMap)
    return {
        addRoutes,
        match
    }
}

function createPathMap (routes, oldPathMap, parent) {
    let pathMap = oldPathMap || {};
    for (let router of routes) {
        const children = router.children
        const path = parent ? `${parent.path}/${router.path}` : router.path
        pathMap[path] = { ...router, path, parent };
        children && createPathMap(children, pathMap, router);
    }
    return { pathMap }
}

export default createMatcher