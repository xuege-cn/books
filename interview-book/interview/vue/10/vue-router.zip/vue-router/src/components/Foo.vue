<template>
    <div>Foo</div>
</template>
<script>

export default {
  name: 'Foo',
}
</script>