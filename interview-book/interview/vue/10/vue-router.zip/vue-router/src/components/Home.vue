<template>
    <div>
        <div>Home</div>

        <router-link to="/home/tel">Tel</router-link>
        <router-link to="/home/about">About</router-link>

        <router-view class="view"></router-view>
    </div>
</template>
<script>

export default {
  name: 'Home',
}
</script>