<template>
    <div>Bar</div>
</template>
<script>

export default {
  name: 'Bar',
  components: {
    
  }
}
</script>