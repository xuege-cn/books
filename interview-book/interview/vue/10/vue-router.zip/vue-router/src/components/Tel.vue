<template>
    <div>Tel</div>
</template>
<script>

export default {
  name: 'Tel',
  components: {
    
  }
}
</script>