<template>
  <div id="app">
    <router-link to="/home">Home</router-link>
    <router-link to="/foo">FOO</router-link>
    <router-link to="/bar">BAR</router-link>

    <router-view class="view"></router-view>
  </div>
</template>

<script>

export default {
  name: 'App',
}
</script>

<style>
a {
  margin: 0 10px;
}
div {
  margin-top: 30px;
}
</style>
