import Home from './components/Home'
import Tel from './components/Tel'
import About from './components/About'
import Foo from './components/Foo'
import Bar from './components/Bar'

const routes = [
    {
        name: 'Home',
        path: '/home',
        component: Home,
        children: [
            {
                name: 'Tel',
                path: 'tel',
                component: Tel,
            },
            {
                name: 'About',
                path: 'about',
                component: About,
            },
        ],
    },
    {
        name: 'Foo',
        path: '/foo',
        component: Foo,
    },
    {
        name: 'Bar',
        path: '/bar',
        component: Bar,
    }
]

export default routes;