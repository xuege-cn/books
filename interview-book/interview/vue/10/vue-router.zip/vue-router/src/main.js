import Vue from 'vue'
// import VueRouter from 'vue-router'
import VueRouter from '@/vue-router'
import App from './App.vue'
import routes from './routes'

Vue.use(VueRouter)
const router = new VueRouter({
    mode: 'hash',
    routes
});

router.beforeHook((to, from, next) => {
    console.log('路由：', to, from)
    setTimeout(() => {
        console.log(1);
        next();
    }, 1000)
})
router.beforeHook((to, from, next) => {
    console.log('路由：', to, from)
    setTimeout(() => {
        console.log(2);
        next();
    }, 1000)
})

new Vue({
    name: 'root',
    router,
    render: h => h(App)
}).$mount('#app')
